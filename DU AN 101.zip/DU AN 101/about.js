// Function to open the side navigation
function openNav() {
    document.getElementById("mysidenav").style.width = "250px";
}

// Function to close the side navigation
function closeNav() {
    document.getElementById("mysidenav").style.width = "0";
}